Gokul Natesan
ggn2104
3/7/2022 



List of References used for assignment 
https://docs.scipy.org/doc/scipy/reference/sparse.html
https://machinelearningmastery.com/sparse-matrices-for-machine-learning/
https://medium.com/hackernoon/implementing-the-perceptron-algorithm-from-scratch-in-python-48be2d07b1c0
https://stackoverflow.com/questions/46503331/how-to-perform-bincount-on-an-array-of-strings 
https://docs.scipy.org/doc/scipy/reference/generated/scipy.sparse.csr_matrix.toarray.html
https://stackoverflow.com/questions/7922487/how-to-transform-numpy-matrix-or-array-to-scipy-sparse-matrix


How to run code:


-For the .py file, run code and make sure to 